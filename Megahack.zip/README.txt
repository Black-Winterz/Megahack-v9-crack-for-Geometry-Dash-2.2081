If you do not have python installed, install it from https://www.python.org/downloads/windows/ before getting started.
After installing it, just double click run.bat to automatically download and install HackMega!
Tip: If you still see the login screen after running the script, make sure the license file exists in %LOCALAPPDATA%\absolllute.megahack, sometimes the copy silently fails and you need to move it manually.

These handouts will never come distributed with any direct executables, if you see anything besides this file, run.bat, and crack.py you might be getting scammed.